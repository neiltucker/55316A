# Domain NIC
$VMName=Get-ItemProperty "HKLM:\Software\Microsoft\Virtual Machine\guest\Parameters" | Select VirtualMachineName | ConvertTo-csv;
$VMFile = $VMName[2].substring(1,13) + ".txt"
$Val1 = (Get-Content D:\$VMFile).substring(1,2)
$Val2 = (Get-Content D:\$VMFile).substring(3,2)
$Val3 = (Get-Content D:\$VMFile).substring(5,2)
$Val4 = (Get-Content D:\$VMFile).substring(7,2)
$Val5 = (Get-Content D:\$VMFile).substring(9,2)
$Val6 = (Get-Content D:\$VMFile).substring(11,2)
$MACAddress = $Val1 + "-" + $Val2 + "-" + $Val3 + "-" + $Val4 + "-" + $Val5 + "-" + $Val6 
$DomainNIC = Get-NetAdapter | Where {$_.MacAddress -eq $MACAddress}
Set-DnsClient -InterfaceIndex $DomainNIC.ifIndex -ConnectionSpecificSuffix "contoso.com"
Set-NetIPAddress -InterfaceIndex $DomainNIC.ifIndex -IPAddress 192.168.10.101
Set-DNSClientServerAddress $DomainNIC.Name -ServerAddresses ("192.168.10.101")

# Internet NIC
$InternetNIC = Get-DNSClient -ConnectionSpecificSuffix "mshome.net"
Set-DNSClientServerAddress $InternetNIC.InterfaceAlias -ServerAddresses ("1.1.1.1", "8.8.8.8")
