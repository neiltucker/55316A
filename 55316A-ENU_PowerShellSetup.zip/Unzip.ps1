# Unzip Setup Files
$Archive = "C:\Labfiles.55316\55316A-ENU_PowerShellSetup.zip"
$WorkFolder = "C:\Labfiles.55316\"
Expand-Archive -LiteralPath $Archive -DestinationPath $WorkFolder -Force
Get-ChildItem -Recurse $WorkFolder | Unblock-File


