﻿# This script configures the Hyper-V Machines used for the 55316 Course.
# Updates to class files can be found on GitHub (https://github.com/neiltucker/55316A). 
# This script will only work on computers that run Hyper-V 3.0 or higher and PowerShell 3.0 or higher.
# The Drive that corresponds to the $VMLOC variable should have at least 100GB of free space available.
# The Drive that corresponds to the $Labfiles variable should have at least 20GB of free space available.
# All the files for the 55316 Student CD should be copied to $Labfiles before running this script.

# Variables
$DC1 = "55316-MIA-SQL"					# Name of VM
$DCRAM = 2GB						# Minimum memory for VM
$DCVHD = 120GB
$Labfiles = "C:\Labfiles.55316"			# Location of all installation files.  Avoid changing.
$SetupFiles = "55316A-ENU_PowerShellSetup.zip"
Expand-Archive $SetupFiles $Labfiles -Force -ErrorAction "SilentlyContinue"
$DCISO = "C:\Labfiles.55316\WS2022.ISO"		# Name of Windows Server ISO
$SQLISO = "C:\Labfiles.55316\SQL2019.ISO"		# Name of SQL Server ISO
$VMLOC = "C:\HyperV"					# Change to drive where most free space is available
$Network1 = "Default Switch"				# If necessary, use existing Hyper-V switch for Internet access
$Network2 = "55316InternalNetwork"			# Internal Network Switch for Contoso.com domain traffic
$VHDMP = "S:"
$StartTime = Get-Date -Format "yyyy-MM-ddTHH:mm:ss"	# Time VM setup process started

# Install PowerShell Modules
If ((Get-PSRepository -Name PSGallery).InstallationPolicy = "Trusted") {Write-Output "PSGallery is already a trusted repository"} Else {Set-PSRepository -Name PSGallery -InstallationPolicy Trusted}
If (Get-PackageProvider -Name NuGet) {Write-Output "NuGet PackageProvider already installed."} Else {Install-PackageProvider -Name "NuGet" -Force -Confirm:$False}
If (Get-Module -ListAvailable -Name PowerShellGet) {Write-Output "PowerShellGet module already installed"} Else {Find-Module PowerShellGet -IncludeDependencies | Install-Module -Force}
If (Get-Module -ListAvailable -Name SQLServer) {Write-Output "SQLServer module already installed" ; Import-Module SQLServer} Else {Install-Module -Name SQLServer -AllowClobber -Force ; Import-Module -Name SQLServer}
Remove-Item -Recurse -Force $Labfiles\SqlServerModule -ErrorAction SilentlyContinue
New-Item -ItemType "Directory" -Path $Labfiles\SqlServerModule -Force
Save-Module -Name SqlServer -Path $Labfiles\SqlServerModule\
Remove-Item -Recurse -Force $Labfiles\PowerShellGet -ErrorAction SilentlyContinue
New-Item -ItemType "Directory" -Path $Labfiles\PowerShellGet -Force
Save-Module -Name PowerShellGet -Path $Labfiles\PowerShellGet

# Load HyperV Module
Write-Output "Load HyperV Module"
Get-ChildItem $PSHome\Modules -Recurse | UnBlock-File -ErrorAction SilentlyContinue
$HyperV = Get-Module Hyper-V
if ($HyperV -eq $Null) {Import-Module Hyper-V -ErrorAction SilentlyContinue}

# Download AdventureWorks & AdventureWorksDW backup files
Write-Output "Download AdventureWorks & AdventureWorksDW backup files"
& $Labfiles\adventureworks_download.ps1
& $Labfiles\adventureworksdw_download.ps1

# Copy Windows Server 2022 Files Needed to Configure Windows Features on VM
Write-Output "     *****     Copy Windows Server 2022 Files     *****"
$TPDCISO = Test-Path $DCISO ; If ($TPDCISO -eq $False){cls ; "The Windows Server 2022 Files could not be found at $DCISO.  Please check the setup instructions and start again." ; Start-Sleep 15 ; exit}
& $Labfiles\ws2022_Files.ps1

# Copy SQL Server 2019 Files
Write-Output "     *****     Copy SQL Server 2019 Setup Files    *****"
$TPSQLISO = Test-Path $SQLISO ; If ($TPSQLISO -eq $False){cls ; "The SQL Server 2019 Files could not be found at $SQLISO.  Please check the setup instructions and start again." ; Start-Sleep 15 ; exit}
& $Labfiles\SQL2019_Files.ps1

# Verify Setup Folders are named properly
$TPWS = Test-Path $Labfiles\Sources\SXS ; If ($TPWS -eq $False){cls ; "The Windows Server 2022 Files are not in $Labfiles\Sources\SXS.  Please check the setup instructions and start again." ; Start-Sleep 15 ; exit}

$VerifySQL = 0
Do {
$TPSQL = Test-Path $Labfiles\SQLServer\SQL2019 ; If ($TPSQL -eq $True) {$VerifySQL = 4} `
Else {$VerifySQL++ ; echo "Trying to Rename SQL Server Setup Folder" ; Start-Sleep 5 ; `
Rename-Item $Labfiles\SQLServer\CDROM1 $Labfiles\SQLServer\SQL2019 -PassThru -Force -ErrorAction SilentlyContinue ;}
}
While ($VerifySQL -le 3)
$TPSQL = Test-Path $Labfiles\SQLServer\SQL2019 ; If ($TPSQL -eq $False){cls ; "The SQL Server Files are not in $Labfiles\SQLServer\SQL2019.  Please check the setup instructions and start again." ; Start-Sleep 15 ; exit}

# Verify that the VMs do not already exist.
Write-Output "Verify that the VMs do not already exist"
$VMDC1 = Get-VM $DC1 -ErrorAction SilentlyContinue; If ($VMDC1) {echo "***   The $DC1 VM already exists.  Please delete it and its resources before using this script.   ***"; Start-Sleep 15 ; exit}
$TPLabfiles = Test-Path $Labfiles ; If ($TPLabfiles -eq $False){cls ; "The $Labfiles folder does not exist." ; "Please verify the location of the classroom setup files." ; Start-Sleep 15 ; exit}
$TPDC1HD1 = Test-Path $VMLOC\$DC1.vhdx ; If ($TPDC1HD1 -eq $True){cls ; "The " + $DC1 + " VHDX already exists.  Verify that the VMs are not already configured." ; Start-Sleep 15 ; exit}
$TPDC1HD2 = Test-Path $VMLOC\Labfiles_$DC1.vhdx ; If ($TPDC1HD2 -eq $True){cls ; "The Labfiles_$DC1 VHDX already exists.  Verify that the VMs are not already configured." ; Start-Sleep 15 ; exit}
remove-vmswitch $Network2 -force -erroraction silentlycontinue
MD $VMLOC -erroraction silentlycontinue

# Create VMs and get MAC Addresses for Network Adapters
Write-Output "Configure VM 55316-MIA-SQL"
$DC1 | new-vm -path $VMLOC -SwitchName $Network1
new-vmswitch $Network2 -SwitchType Internal
get-vm $DC1 | add-vmnetworkadapter -switchname $Network2
get-vm $DC1 | set-vmprocessor -Count 4 -Reserve 25 -Maximum 80
get-vm $DC1 | set-vmmemory -dynamicmemoryenabled $true -MinimumBytes $DCRAM -StartupBytes $DCRAM -MaximumBytes 6GB
get-vm $DC1 | Start-VM
Start-Sleep 10
$DC1MAC = Get-VMNetWorkAdapter $DC1 | Where {$_.SwitchName -eq $Network2} | Select MacAddress | Convertto-csv; $DC1MAC[2] | Out-File $Labfiles\$DC1.txt
$DC1MAC1 = Get-Content $Labfiles\$DC1.txt
get-vm $DC1 | Stop-VM -Turnoff -Force

# Create and Mount Drives and Controllers
Write-Output "     *****     Create VHDX used for Labfiles     *****" 
& $Labfiles\labfiles.ps1
new-vhd -path $VMLOC\$DC1.vhdx -size $DCVHD
add-vmharddiskdrive -vmname $DC1 -controllernumber 0 -controllertype ide -path $VMLOC\$DC1.VHDX
add-vmharddiskdrive -vmname $DC1 -controllernumber 0 -controllertype ide -path $VMLOC\Labfiles_$DC1.VHDX
remove-vmdvddrive -controllernumber 1 -controllerlocation 0 -vmname $DC1 -erroraction SilentlyContinue
add-vmdvddrive -controllernumber 1 -controllerlocation 0 -vmname $DC1 -Path $DCISO 
set-vmfloppydiskdrive $DC1 $Labfiles\dc1install.vfd

# Configure VMs
start-vm $DC1
Write-Output "Automated setup of virtual machine 55316-MIA-SQL is now starting.  Progress can be checked in Hyper-V Manager.  The setup should finish in less than one hour."
$et = Get-Date
$EndTime = $et.ToString("yyyy-MM-ddTHH:mm:ss")
$outputfile = "55316HyperVSetup" + $et.ToString("yyyyMMddHHmmss") + ".txt" 
Write-Output "Start Time:    $StartTime" > $Labfiles"\"$outputfile
Write-Output "End Time:      $EndTime" >> $Labfiles"\"$outputfile
Write-Output "VM Name:       $DC1" >> $Labfiles"\"$outputfile
Write-Output "Contoso MAC:   $DC1MAC1" >> $Labfiles"\"$outputfile
Get-Content $Labfiles"\"$outputfile

