reg import C:\Classfiles\DC\ie.reg
Set-ItemProperty -Path 'HKLM:\Software\Microsoft\ServerManager' -name "DoNotOpenServerManagerAtLogon" -Value 1 -Confirm:$False

### Install PowerShell Modules
Install-Module -Name SQLServer -AllowClobber -Force 
Set-PSRepository -Name PSGallery -InstallationPolicy Trusted
Install-PackageProvider -Name "NuGet" -Force -Confirm:$False
Copy-Item -Path C:\Classfiles\PowerShellGet\ -Destination $Env:ProgramFiles\WindowsPowerShell\Modules\PowerShellGet -Recurse -Force
Copy-Item -Path C:\Classfiles\SqlServerModule\SqlServer\ -Destination $Env:ProgramFiles\WindowsPowerShell\Modules\SqlServer -Recurse -Force
Import-Module -Name SQLServer

#   Configure Windows Explorer Settings
$VarWindowsExplorer = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
Set-ItemProperty $VarWindowsExplorer AlwaysShowMenus 1 -Force
Set-ItemProperty $VarWindowsExplorer FolderContentsInfoTip 1 -Force
Set-ItemProperty $VarWindowsExplorer Hidden 1 -Force
Set-ItemProperty $VarWindowsExplorer HideDrivesWithNoMedia 0 -Force
Set-ItemProperty $VarWindowsExplorer HideFileExt 0 -Force
Set-ItemProperty $VarWindowsExplorer IconsOnly 0 -Force
Set-ItemProperty $VarWindowsExplorer ShowSuperHidden 0 -Force
Set-ItemProperty $VarWindowsExplorer ShowStatusBar 1 -Force

#   Disable IE ESC
$VarAdministratorKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
$VarUserKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
Set-ItemProperty -Path $VarAdministratorKey -Name "IsInstalled" -Value 0
Set-ItemProperty -Path $VarUserKey -Name "IsInstalled" -Value 0

#   Configure Desktop Settings
Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Force
$shell = New-Object -ComObject WScript.Shell
$Location = [System.Environment]::GetFolderPath('Desktop')
$Computer = $shell.CreateShortcut("$Location\ $env:ComputerName.lnk")
$Computer.TargetPath = "Explorer.exe"
$Computer.IconLocation = "imageres.dll,104"
$Computer.HotKey = "CTRL+ALT+E"
$Computer.Save()
$PowerShell = $shell.CreateShortcut("$Location\ PowerShell.lnk")
$PowerShell.TargetPath = "PowerShell.exe"
$PowerShell.IconLocation = "PowerShell.exe"
$PowerShell.HotKey = "CTRL+ALT+P"
$PowerShell.Save()
$PowerShell_ISE = $shell.CreateShortcut("$Location\ PowerShell_ISE.lnk")
$PowerShell_ISE.TargetPath = "PowerShell_ise.exe"
$PowerShell_ISE.IconLocation = "powershell_ise.exe"
$PowerShell_ISE.HotKey = "CTRL+ALT+I"
$PowerShell_ISE.Save()
$CMD = $shell.CreateShortcut("$Location\Command Prompt.lnk")
$CMD.TargetPath = "cmd.exe"
$CMD.IconLocation = "cmd.exe"
$CMD.HotKey = "CTRL+ALT+C"
$CMD.Save()
$CMD = $shell.CreateShortcut("$Location\SQL Server Management Studio.lnk")
$CMD.TargetPath = "C:\Program Files (x86)\Microsoft SQL Server Management Studio 19\Common7\IDE\Ssms.exe"
$CMD.IconLocation = "C:\Program Files (x86)\Microsoft SQL Server Management Studio 19\Common7\IDE\Ssms.exe"
$CMD.HotKey = "CTRL+ALT+S"
$CMD.Save()

#   Add Windows Features
Import-Module ServerManager
$SMTP = Get-WindowsFeature "smtp-server"
$TELNET = Get-WindowsFeature "telnet-client"
$DNS = Get-WindowsFeature "DNS"
$RSAT = Get-WindowsFeature "RSAT"
$PrintToPDF = Get-WindowsOptionalFeature -Online -FeatureName Printing-PrintToPDFServices-Features
$NetFx3 = Get-WindowsOptionalFeature -Online -FeatureName NetFx3
if(!$SMTP.Installed){Add-WindowsFeature $SMTP}
if(!$TELNET.Installed){Add-WindowsFeature $TELNET}
if(!$DNS.Installed){Add-WindowsFeature $DNS}
if(!$RSAT.Installed){Add-WindowsFeature $RSAT -IncludeAllSubFeature}
if($PrintToPDF.State -ne "Enabled"){Enable-WindowsOptionalFeature -Online -Featurename Printing-PrintToPDFServices-Features -All}
if($NetFx3.State -ne "Enabled"){Enable-WindowsOptionalFeature -Online -Featurename Netfx3 -All}
Set-Service -Name "SMTPSVC" -StartupType Automatic
Start-Service -Name "SMTPSVC"
Set-WSManQuickConfig -Force


