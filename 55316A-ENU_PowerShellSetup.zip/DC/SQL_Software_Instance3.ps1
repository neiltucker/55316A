echo off
cls
echo "*****   Installing SQL Server 2019 Instance "SQL3"   *****"
echo "*****   Please wait while components are configured (10 - 20 minutes)   *****"
echo .
echo .
echo .
C:\SQLServerFull\Setup.exe /INDICATEPROGRESS /IACCEPTSQLSERVERLICENSETERMS /CONFIGURATIONFILE=C:\Classfiles\DC\SQL_Software_Instance3.INI
