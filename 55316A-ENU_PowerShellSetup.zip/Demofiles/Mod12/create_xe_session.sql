-- Create an Extended Event session (AW2019) that monitors T-SQL events in the AdventureWorks2019 database
-- To test the session, run it and then execute queries on the AdventureWorks2019 database
-- Review the "Live Data" to get information about the duration of each query

-- Step 1 - Create the session
CREATE EVENT SESSION [AW2019] ON SERVER 
ADD EVENT sqlserver.rpc_completed(SET collect_data_stream=(1)
    ACTION(package0.collect_system_time,sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.database_name,sqlserver.session_id)
    WHERE ((([package0].[greater_than_uint64]([sqlserver].[database_id],(4))) AND ([package0].[equal_boolean]([sqlserver].[is_system],(0)))) AND ([sqlserver].[database_name]=N'adventureworks2019'))),
ADD EVENT sqlserver.sql_batch_completed(
    ACTION(package0.collect_system_time,sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.database_name,sqlserver.session_id)
    WHERE ((([package0].[greater_than_uint64]([sqlserver].[database_id],(4))) AND ([package0].[equal_boolean]([sqlserver].[is_system],(0)))) AND ([sqlserver].[database_name]=N'adventureworks2019')))
ADD TARGET package0.event_file(SET filename=N'C:\Backup\aw2019.xel',max_file_size=(10))
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=ON,STARTUP_STATE=ON)
GO

-- Step 2 - Start the session
/*
a. In SSMS, go to Object Explorer > Management > Extended Events > AW2019 

b. Right-click AW2019 and choose "Start Session"
*/

-- Step 3 - Execute queries on AdventureWorks2019
USE AdventureWorks2019
GO
SELECT db_name() AS [Database Name], db_id() AS [Database ID]
GO
SELECT * FROM Person.Person
GO
SELECT BusinessEntityID,FirstName,LastName FROM Person.Person
WHERE BusinessEntityID < 100
GO
SELECT * FROM HumanResources.Employee
GO
SELECT * FROM HumanResources.vEmployee
GO

-- Step 4 - Review the Events
/*
a. In SSMS, go to Object Explorer > Management > Extended Events > AW2019 

b. Right-click AW2019 and choose "Watch Live Data"

c. In the "Live Data" window, use the "Details" folder at the bottom to verify the following details for each batch:
	i.   database_name
	ii.  duration
	iii. logical_reads
*/


