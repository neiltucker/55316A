USE Master
GO
DROP DATABASE IF EXISTS hr
GO
CREATE DATABASE hr
GO
USE hr
GO
SELECT BusinessEntityID as ID, FirstName,LastName,JobTitle,PhoneNumber,PhoneNumberType,EmailAddress 
INTO dbo.employees 
FROM AdventureWorks2019.HumanResources.vEmployee
GO
