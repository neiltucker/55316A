### Export data from SQL Server database in CSV, XML and JSON formats using PowerShell

Import-Module SqlServer
Set-Location SQLSERVER:\SQL\MIA-SQL\Default\Databases\AdventureWorks2019
Invoke-Sqlcmd -Query "SELECT FIRSTNAME, LASTNAME FROM PERSON.PERSON" -ServerInstance "MIA-SQL" -database "adventureWorks2019" | `
Export-CSV -Path "C:\Classfiles\Person.csv" 

Invoke-Sqlcmd -Query "SELECT FIRSTNAME, LASTNAME FROM PERSON.PERSON" -ServerInstance "MIA-SQL" -database "adventureWorks2019" | `
Export-Clixml -Path "C:\Classfiles\Person.xml" 

Invoke-Sqlcmd -Query "SELECT FIRSTNAME, LASTNAME FROM PERSON.PERSON" -ServerInstance "MIA-SQL" -database "adventureWorks2019" | `
ConvertTo-Json -Depth 2 | Out-File "C:\Classfiles\Person.json" 

