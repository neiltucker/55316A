### Expore SQL Server Management Objects using PowerShell 
### Run the commands one line at a time

### 1. Try commonly used PowerShell cmdlets
Get-Help Get-Command
help gcm
Get-Help Import-Module
Get-Command Get-*
Get-Command *-Module
Get-Command -Module SQLServer
(gcm -module sqlserver).count

### 2. These steps have already been done on this system and are not required.  
### They would be required on a system where the SqlServer module has not already been installed.
Set-PSRepository -Name PSGallery -InstallationPolicy Trusted
Install-PackageProvider -Name "NuGet" -Force -Confirm:$False
Install-Module -Name SqlServer -AllowClobber -Force -Repository PSGallery

### 3. Work with the SqlServer Module
Import-Module SqlServer
Get-PSDrive -PSProvider SqlServer
Set-Location SQLSERVER:\
CD SQL\
Get-ChildItem
CD MIA-SQL
Get-ChildItem
CD Default
Get-ChildItem
CD Databases

### 4. Verify that the AdventureWorks2019 and AdventureWorksDW2019 databases are listed
Get-ChildItem
Get-ChildItem | Get-Member
Get-ChildItem | Select-Object Name, Size, RecoveryModel, Owner
Get-Location
Set-Location HKLM:\Software
Get-ChildItem
Set-Location C:\Classfiles
Get-ChildItem
Get-ChildItem *.ps1

