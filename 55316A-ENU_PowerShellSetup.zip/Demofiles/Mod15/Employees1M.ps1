### Create an employees1M.csv file with 1 million records
### This script may take up to 15 minutes to run.  It is best to run it before starting the module.

# Set parameters for file generation
$outputFile = "employees1M.csv"
$numberOfRecords = 1000000

# Expanded arrays of sample names for more variation
$lastNames = @(
    'Smith', 'Johnson', 'Williams', 'Brown', 'Jones',
    'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez',
    'Hernandez', 'Lopez', 'Gonzalez', 'Wilson', 'Anderson',
    'Thomas', 'Taylor', 'Moore', 'Jackson', 'Martin',
    'Lee', 'Perez', 'Thompson', 'White', 'Harris'
)

$firstNames = @(
    'James', 'John', 'Robert', 'Michael', 'William',
    'David', 'Richard', 'Joseph', 'Thomas', 'Christopher',
    'Mary', 'Patricia', 'Jennifer', 'Linda', 'Elizabeth',
    'Susan', 'Sarah', 'Karen', 'Nancy', 'Lisa',
    'Emma', 'Olivia', 'Ava', 'Isabella', 'Sophia'
)

# Create CSV header
"ID,LastName,FirstName,HireDate,HireTime" | Out-File $outputFile -Encoding UTF8

# Get current date for hire date calculations
$startDate = Get-Date
$endDate = $startDate.AddYears(2)

# Generate records
1..$numberOfRecords | ForEach-Object {
    $id = $_
    $lastName = $lastNames[(Get-Random -Maximum $lastNames.Length)]
    $firstName = $firstNames[(Get-Random -Maximum $firstNames.Length)]
    
    # Generate random hire dates
    $randomDays = Get-Random -Minimum -730 -Maximum -7
    $hireDate = $startDate.AddDays($randomDays).ToString("yyyy-MM-dd")
    
    # Generate random time between 8 AM and 5 PM
    $hour = Get-Random -Minimum 8 -Maximum 17
    $minute = Get-Random -Minimum 0 -Maximum 59
    $hireTime = "{0:D2}:{1:D2}:00" -f $hour, $minute
    
    # Create and write the record
    "$id,$lastName,$firstName,$hireDate,$hireTime" | Out-File $outputFile -Append -Encoding UTF8
}

Copy-Item $outputFile C:\Classfiles\Tools
Copy-Item $outputFile C:\Temp
Write-Host "File '$outputFile' has been created with $numberOfRecords records."

