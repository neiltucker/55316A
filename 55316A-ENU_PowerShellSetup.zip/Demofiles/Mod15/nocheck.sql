-- Module 15 - Disabling, Enabling and Rebuilding Constraints (Using NOCHECK)
-- Execute the C:\Classfiles\DemoFiles\Mod15\employees1M.ps1 before running the script (15 minutes)

-- Step 1 - Connect to AdventureWorks2019 and create Employees
USE AdventureWorks2019
GO

IF OBJECT_ID('Employees', 'U') IS NOT NULL
    DROP TABLE Employees;
GO

CREATE TABLE Employees (
    ID INT PRIMARY KEY,
    LastName NVARCHAR(50) NOT NULL,
    FirstName NVARCHAR(50) NOT NULL,
    HireDate DATE NOT NULL,
    HireTime TIME NOT NULL
);
GO

-- Step 2: Add a CHECK constraint to enforce valid HireDate (Note: NOT FOR REPLICATION constraints are ignored during BULK INSERT and replication operations)
ALTER TABLE Employees
ADD CONSTRAINT CHK_HireDate CHECK (HireDate <= GETDATE());
GO

-- Step 3: Try inserting a single row (This INSERT statement will succeed because it complies with the CHECK constraint)
INSERT INTO Employees (ID, LastName, FirstName, HireDate, HireTime)
VALUES (1, 'Smith', 'John', DATEADD(week, -1, GETDATE()), '09:30:00');

-- Step 4: Query, then truncate the table for next step
SELECT * FROM Employees
GO
TRUNCATE TABLE Employees;
GO

-- Step 5: Try inserting a single row (This INSERT statement will fail because it violates the CHECK constraint)
INSERT INTO Employees (ID, LastName, FirstName, HireDate, HireTime)
VALUES (1, 'Smith', 'John', DATEADD(week, 1, GETDATE()), '09:30:00');

-- Step 6: Disable the CHECK constraint with NOCHECK
ALTER TABLE Employees NOCHECK CONSTRAINT CHK_HireDate;
GO

sp_helpconstraint 'Employees'  -- Verify the status of CHECK on HireDate is "Disabled"
GO

-- Step 7: Demonstrate OPENROWSET Import with CHECK disabled
PRINT 'Attempting OPENROWSET import with CHECK constraint disabled...';

-- Temporarily disable the CHECK constraint
ALTER TABLE Employees NOCHECK CONSTRAINT ALL;

-- Measure start time
DECLARE @StartTime DATETIME = GETDATE();

BEGIN TRY
    -- Perform the import using OPENROWSET
    INSERT INTO Employees (ID, LastName, FirstName, HireDate, HireTime)
    SELECT *
    FROM OPENROWSET(
        BULK 'C:\Classfiles\Tools\employees1M.csv',
        FORMATFILE = 'C:\Classfiles\Tools\employees1M.fmt',
		FIRSTROW = 2
    ) AS SourceFile;

    PRINT 'OPENROWSET import completed successfully.';
END TRY
BEGIN CATCH
    PRINT 'Error during OPENROWSET import:';
    PRINT ERROR_MESSAGE();
END CATCH;

-- Measure end time and calculate duration
DECLARE @EndTime DATETIME = GETDATE();
PRINT 'Time taken with CHECK constraint disabled: ' + CAST(DATEDIFF(SECOND, @StartTime, @EndTime) AS NVARCHAR) + ' seconds.';

-- Step 8: Truncate the table and enable the CHECK constraint
SELECT * FROM Employees;
GO

TRUNCATE TABLE Employees;
GO

ALTER TABLE Employees CHECK CONSTRAINT ALL;
GO

sp_helpconstraint 'Employees'  -- Verify the status of CHECK on HireDate is "Enabled"
GO

-- Step 9: Demonstrate OPENROWSET Import with CHECK enabled
PRINT 'Attempting OPENROWSET import with CHECK constraint enabled...';

-- Ensure the CHECK constraint is enabled
ALTER TABLE Employees CHECK CONSTRAINT ALL;

-- Measure start time
DECLARE @StartTime DATETIME = GETDATE();

BEGIN TRY
    -- Perform the import using OPENROWSET
    INSERT INTO Employees (ID, LastName, FirstName, HireDate, HireTime)
    SELECT *
    FROM OPENROWSET(
        BULK 'C:\Classfiles\Tools\employees1M.csv',
        FORMATFILE = 'C:\Classfiles\Tools\employees1M.fmt',
        FIRSTROW = 2 -- Skip the header row
    ) AS SourceFile;

    PRINT 'OPENROWSET import with CHECK constraint enabled completed successfully.';
END TRY
BEGIN CATCH
    PRINT 'Error during OPENROWSET import:';
    PRINT ERROR_MESSAGE();
END CATCH;

-- Measure end time and calculate duration
DECLARE @EndTime DATETIME = GETDATE();
PRINT 'Time taken with CHECK constraint enabled: ' + CAST(DATEDIFF(SECOND, @StartTime, @EndTime) AS NVARCHAR) + ' seconds.';
GO

-- Step 10: Review the results
SELECT * FROM Employees;
GO
