-- Recreate the aw database

USE master
GO
IF EXISTS(SELECT * FROM sys.databases WHERE name = 'aw') DROP DATABASE aw
GO
CREATE DATABASE aw
GO

USE aw
GO
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'vEmployee') DROP TABLE dbo.vEmployee
SELECT BusinessEntityID as ID,FirstName,LastName,JobTitle,PhoneNumber,EmailAddress INTO aw.dbo.vEmployee FROM AdventureWorks2019.HumanResources.vEmployee
GO

