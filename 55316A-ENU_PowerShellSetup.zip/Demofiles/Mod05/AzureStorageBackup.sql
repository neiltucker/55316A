CREATE CREDENTIAL [https://55316in5516sa.blob.core.windows.net/55316share] WITH IDENTITY='Shared Access Signature', SECRET='sv=2020-08-04&si=55316Policy&sr=c&sig=XkgwWOaOgvNPpBx%2BCoycJObOmo%2FzIcMTqbihwhY9hr0%3D'

SELECT * FROM sys.credentials

BACKUP DATABASE aw TO URL = 'https://55316in5516sa.blob.core.windows.net/55316share/aw.bak'

