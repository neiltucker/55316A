Remove-Item -Recurse -Force $Labfiles\SQLServer -ErrorAction SilentlyContinue
DisMount-Diskimage -DevicePath \\.\CDROM0 -ErrorAction SilentlyContinue
DisMount-Diskimage -DevicePath \\.\CDROM1 -ErrorAction SilentlyContinue
New-Item -ItemType "Directory" -Path $Labfiles\SQLServer -Force
$SQLImage = Mount-DiskImage $SQLISO 
$SQLPath = $SQLImage.DevicePath
$SQLDrive = $SQLPath.Substring(4,6)
Copy-Item -Path $SQLPath"\" -Destination $Labfiles\SQLServer -Recurse -Force 
DisMount-DiskImage -DevicePath $SQLPath 
Rename-Item $Labfiles\SQLServer\$SQLDrive $Labfiles\SQLServer\SQL2019 -Force



