# Download Adventureworks DW Database

$WorkFolder = "C:\Labfiles.55316\"
$AdventureWorksDB = "AdventureworksDW2019.bak"
$AdventureWorksDBPATH = $WorkFolder + $AdventureWorksDB 
$AdventureWorksURL = "https://github.com/Microsoft/sql-server-samples/releases/download/adventureworks/" + $AdventureWorksDB

Invoke-WebRequest -Uri $AdventureworksURL -OutFile $AdventureWorksDBPATH
Start-Sleep 5
IF (Test-Path $AdventureWorksDBPATH) {
Write-Output "AdventureworksDW Backup downloaded successfully."}






