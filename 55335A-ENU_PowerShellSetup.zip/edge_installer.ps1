$EdgePath = join-path C:\temp MicrosoftEdgeEnterpriseX64.msi
Invoke-WebRequest 'https://msedge.sf.dl.delivery.mp.microsoft.com/filestreamingservice/files/a2662b5b-97d0-4312-8946-598355851b3b/MicrosoftEdgeEnterpriseX64.msi'  -OutFile $EdgePath
Start-Process "$EdgePath" -ArgumentList "/quiet /passive"
Start-Sleep 60

