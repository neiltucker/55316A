$adsUrl = "https://go.microsoft.com/fwlink/?linkid=2274898"
$adsInstallerPath = "$env:TEMP\AzureDataStudioSetup.exe"

# Download and setup Azure Data Studio
Write-Host "Downloading Azure Data Studio installer..."
Invoke-WebRequest -Uri $adsUrl -OutFile $adsInstallerPath
Start-Process -FilePath $adsInstallerPath -ArgumentList "/SILENT" -Wait

# Clean up the Azure Data Studio installer
Remove-Item -Path $adsInstallerPath -Force
Write-Host "Azure Data Studio installation completed."
