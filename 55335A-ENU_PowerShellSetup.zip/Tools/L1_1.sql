-- Lab 1, Exercise 1: Enable the use of external scripts in SQL Server
USE [master]
GO
sp_configure 'show advanced options', 1
GO
RECONFIGURE
GO
sp_configure 'external scripts enabled', 1
GO
RECONFIGURE
GO

