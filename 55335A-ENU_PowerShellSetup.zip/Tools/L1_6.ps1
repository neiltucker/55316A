﻿# Lab 1, Exercise 6: Register Python runtime with SQL Server

$arguments = "/configure /pythonhome:`"$pythonHome`" /instance:`"$sqlServerService`""
Start-Process -FilePath $registerRextPath -ArgumentList $arguments -Wait -NoNewWindow

# Restart SQL Server and SQL Server Launchpad services
Restart-Service -Name $sqlServerService -Force
Restart-Service -Name $launchpadService -Force

