EXECUTE sp_execute_external_script
@language = N'Python', @script = N'
import pandas
import numpy
import pkg_resources
dists = [str(d) for d in pkg_resources.working_set]
OutputDataSet = pandas.DataFrame(dists)
'
