﻿# Lab 1, Exercise 2: Install R

# Set the R installation variables
$rVersion = "4.3.2"
$downloadUrl = "https://cran.r-project.org/bin/windows/base/old/4.3.2/R-4.3.2-win.exe"
$installDir = "C:\Program Files\R\R-$rVersion"
$registerRextPath = "C:\Program Files\R\R-$rVersion\library\RevoScaleR\rxLibs\x64\RegisterRext.exe"
$rHome = "C:\Program Files\R\R-$rVersion"
$sqlServerService = "MSSQLSERVER"
$launchpadService = "MSSQLLaunchpad"

# Download R installer
$installerPath = "$env:TEMP\R-$rVersion-win.exe"
Invoke-WebRequest -Uri $downloadUrl -OutFile $installerPath

# Install R silently
Start-Process -FilePath $installerPath -ArgumentList "/VERYSILENT /DIR=`"$installDir`"" -Wait

# Set PATH environment variable
$env:PATH += ";$installDir\bin"
[Environment]::SetEnvironmentVariable("PATH", $env:PATH, [EnvironmentVariableTarget]::Machine)

# Function to install R packages
function Install-RPackage($packageName) {
    $rScript = "install.packages('$packageName', repos='https://cran.rstudio.com/')"
    & "$installDir\bin\Rscript.exe" -e $rScript
}

# Install R packages
Install-RPackage "iterators"
Install-RPackage "foreach"
Install-RPackage "R6"
Install-RPackage "jsonlite"
Install-RPackage "RODBC"

# Install packages from URLs
$urlPackages = @(
    "https://aka.ms/sqlml/r4.2/windows/CompatibilityAPI_1.1.0.zip",
    "https://aka.ms/sqlml/r4.2/windows/RevoScaleR_10.0.1.zip"
)

foreach ($url in $urlPackages) {
    $rScript = "install.packages('$url', repos=NULL)"
    & "$installDir\bin\Rscript.exe" -e $rScript
}

# Register R runtime with SQL Server
$arguments = "/configure /rhome:`"$rHome`" /instance:`"$sqlServerService`""
Start-Process -FilePath $registerRextPath -ArgumentList $arguments -Wait -NoNewWindow

# Restart SQL Server and SQL Server Launchpad services
Restart-Service -Name $sqlServerService -Force
Restart-Service -Name $launchpadService -Force

