﻿# Lab 1, Exercise 5: Install Python

# Configure Variables
$sqlServerService = "MSSQLSERVER"
$launchpadService = "MSSQLLaunchpad"

# Step 1: Download Python 3.10.11
$pythonUrl = "https://www.python.org/ftp/python/3.10.11/python-3.10.11-amd64.exe"
$installerPath = "$env:TEMP\python-3.10.11-amd64.exe"
Invoke-WebRequest -Uri $pythonUrl -OutFile $installerPath

# Step 2: Install Python
$installArgs = "/quiet InstallAllUsers=1 PrependPath=1 Include_test=0"
Start-Process -FilePath $installerPath -ArgumentList $installArgs -Wait

# Refresh environment variables
$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")

# Step 3: Update PIP
Write-Host "Updating pip to the latest version..."
& python -m pip install --upgrade pip
$pipVersion = & python -m pip --version
Write-Host "Updated pip version: $pipVersion"

# Step 4: Install required packages and assign SQL Server  permissions
$pythonPath = "C:\Program Files\Python310\"
$pythonLibPath = "C:\Program Files\Python310\Lib\site-packages"

cd $pythonPath
python -m pip install -t $pythonLibPath dill numpy==1.22.0 pandas patsy python-dateutil --upgrade
python -m pip install -t $pythonLibPath https://aka.ms/sqlml/python3.10/windows/revoscalepy-10.0.1-py3-none-any.whl --upgrade

icacls $pythonLibPath /grant "NT Service\MSSQLLAUNCHPAD:(OI)(CI)RX" /T
icacls $pythonLibPath /grant "SQLService:(OI)(CI)RX" /T
icacls $pythonLibPath /grant "*S-1-15-2-1:(OI)(CI)RX" /T

# Register Python runtime with SQL Server
$PythonHome = "C:\Program Files\Python310"
$registerRextPath = "C:\Program Files\Python310\Lib\site-packages\revoscalepy\rxLibs\"
cd $registerRextPath
.\RegisterRext.exe /configure /pythonhome:$pythonHome /instance:$sqlServerService

# Restart SQL Server and SQL Server Launchpad services
Restart-Service -Name $sqlServerService -Force
Restart-Service -Name $launchpadService -Force

