﻿### Configure Objects & Variables
Set-StrictMode -Version 2.0
Set-Item Env:\SuppressAzurePowerShellBreakingChangeWarnings "true"
$WorkFolder = "C:\Labfiles.55315\"                                     # 55315A-ENU_PowerShellSetup.zip must be in this location
Set-Location $WorkFolder
$Location = "WESTEUROPE"
$ResourceGroupName = "55315gen"
$SAShare = "55315"
$VMDC = "55315MIASQL"
$vmName = $VMDC
$rgName = $ResourceGroupName
$imageName = $VMDC

### Login to Azure
Connect-AzAccount
$SubscriptionName = (Get-AzSubscription)[0].Name
$Subscription = Get-AzSubscription -SubscriptionName $SubscriptionName | Select-AzSubscription

### Deallocate (Stop) Azure VM
Stop-AzVM -ResourceGroupName $rgName -Name $vmName -Force

### Generalize Azure VM
Set-AzVm -ResourceGroupName $rgName -Name $vmName -Generalized

### Create VM Image in AzureLabs Resource Group
$vm = Get-AzVM -Name $vmName -ResourceGroupName $rgName
$image = New-AzImageConfig -Location $location -SourceVirtualMachineId $vm.Id
New-AzImage -Image $image -ImageName $imageName -ResourceGroupName "AzureLabs"

### VM Image Definition
$PublisherName = "MicrosoftSQLServer"
$Offer = (Get-AzVMImageOffer -Location $Location -PublisherName $PublisherName | Where-Object {$_.Offer -match "SQL2019-WS2019"})[0].Offer 
$Skus = (Get-AzVMImagesku -Location $Location -PublisherName $PublisherName -Offer $Offer | Where-Object {$_.Skus -match "SQLDEV"})[0].Skus
$Offer   #sql2019-ws2019
$Skus    #sqldev
