﻿# Register R runtime with SQL Server
$arguments = "/configure /rhome:`"$rHome`" /instance:`"$sqlServerService`""
Start-Process -FilePath $registerRextPath -ArgumentList $arguments -Wait -NoNewWindow

# Restart SQL Server and SQL Server Launchpad services
Restart-Service -Name $sqlServerService -Force
Restart-Service -Name $launchpadService -Force

