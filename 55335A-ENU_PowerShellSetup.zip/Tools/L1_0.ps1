﻿# L1:  Run this script before performing any of the exercises.  
# It will make sure that the SQL Server and SQL Server Launchpad services are configured to startup automatically.

# Configure Variables
$sqlServerService = "MSSQLSERVER"
$launchpadService = "MSSQLLaunchpad"

Set-Service -Name $sqlServerService -StartupType Automatic
Set-Service -Name $launchpadService -StartupType Automatic

Restart-Service -Name $sqlServerService -Force
Restart-Service -Name $launchpadService -Force
