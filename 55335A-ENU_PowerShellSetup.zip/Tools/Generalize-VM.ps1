﻿### Sysprep the system and shutdown the computer (Perform in Administrator Command Prompt)
# rmdir %C:\Windows\Panther
# C:\Windows\System32\sysprep.exe 

### Login to Azure
Connect-AzAccount
$SubscriptionName = (Get-AzSubscription)[0].Name
$Subscription = Get-AzSubscription -SubscriptionName $SubscriptionName | Select-AzSubscription

### Variables
$ResourceGroupName = "init55315rg"
$Location = (Get-AzResourceGroup -ResourceGroupName $ResourceGroupName).Location
$DiskName = "55315MIASQL_OsDisk_1_0244f51b59534f999de43520d3897aea"
$Disk = Get-AzDisk -ResourceGroupName $ResourceGroupName -DiskName $DiskName
$ImageName = "55315generalized"

### Create the image
$ImageConfig = New-AzImageConfig -Location $Location
$ImageConfig = Set-AzImageOsDisk -Image $ImageConfig -OsState Generalized -OsType Windows -ManagedDiskId $Disk.Id
$Image = New-AzImage -ImageName $ImageName -ResourceGroupName "AzureLabs" -Image $ImageConfig