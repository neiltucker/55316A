﻿# Lab 1, Exercise 8: Install Java

$jdkUrl = "https://download.oracle.com/java/17/latest/jdk-17_windows-x64_bin.exe"
$output = "C:\Temp\jdk-17_windows-x64_bin.exe"
$installPath = "C:\Program Files\Java\jdk-17"

# Download JDK
Invoke-WebRequest -Uri $jdkUrl -OutFile $output

# Install JDK
Start-Process -FilePath $output -ArgumentList "/s INSTALLDIR=$installPath" -Wait

# Set JAVA_HOME and update PATH
[System.Environment]::SetEnvironmentVariable("JAVA_HOME", $installPath, [System.EnvironmentVariableTarget]::Machine)
$env:Path += ";$installPath\bin"
[System.Environment]::SetEnvironmentVariable("Path", $env:Path, [System.EnvironmentVariableTarget]::Machine)