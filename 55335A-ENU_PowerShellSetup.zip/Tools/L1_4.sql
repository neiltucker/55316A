-- Lab 1, Exercise 2: Verify R runtime works in SQL Server

-- Test R execution
DECLARE @RScript NVARCHAR(MAX)
DECLARE @InputDataSet NVARCHAR(MAX)

SET @RScript = N'
# Create a simple data frame
df <- data.frame(
  Name = c("Alice", "Bob", "Charlie", "David"),
  Age = c(25, 30, 35, 40),
  Score = c(85, 92, 78, 95)
)

# Calculate mean age and score
mean_age <- mean(df$Age)
mean_score <- mean(df$Score)

# Create output data frame
OutputDataSet <- data.frame(
  MeanAge = mean_age,
  MeanScore = mean_score,
  RVersion = R.version.string
)
'

SET @InputDataSet = N'SELECT 1 as DummyColumn'

-- Execute R script
EXEC sp_execute_external_script
  @language = N'R',
  @script = @RScript,
  @input_data_1 = @InputDataSet,
  @output_data_1_name = N'OutputDataSet'
WITH RESULT SETS ((
  MeanAge FLOAT,
  MeanScore FLOAT,
  RVersion NVARCHAR(100)
))

GO

-- Test specific R packages
DECLARE @RScript NVARCHAR(MAX)

SET @RScript = N'
library(jsonlite)
library(RODBC)
library(RevoScaleR)

OutputDataSet <- data.frame(
  Package = c("jsonlite", "RODBC", "RevoScaleR"),
  Version = c(
    as.character(packageVersion("jsonlite")),
    as.character(packageVersion("RODBC")),
    as.character(packageVersion("RevoScaleR"))
  )
)
'

-- Execute R script to check package versions
EXEC sp_execute_external_script
  @language = N'R',
  @script = @RScript
WITH RESULT SETS ((
  Package NVARCHAR(50),
  Version NVARCHAR(20)
))

GO

EXECUTE sp_execute_external_script
@language = N'R',
@script = N'OutputDataSet <- InputDataSet;'
GO
EXEC sp_execute_external_script
@language = N'R',
@script = N'OutputDataSet <- as.data.frame( runif(10,1000,2000) );'
WITH RESULT SETS(([10 Random Numbers] FLOAT));
GO