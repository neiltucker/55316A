-- Recreate the aw database

USE master
GO
IF EXISTS(SELECT * FROM sys.databases WHERE name = 'aw7') DROP DATABASE aw7
GO
CREATE DATABASE aw7
GO

USE aw7
GO
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'vEmployee') DROP TABLE dbo.vEmployee
SELECT BusinessEntityID as ID,FirstName,LastName,JobTitle,PhoneNumber,EmailAddress INTO aw7.dbo.vEmployee FROM AdventureWorks2019.HumanResources.vEmployee
GO

