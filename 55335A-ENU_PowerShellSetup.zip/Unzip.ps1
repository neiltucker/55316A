# Unzip Setup Files
$Archive = "C:\Labfiles.55335\55335A-ENU_PowerShellSetup.zip"
$WorkFolder = "C:\Labfiles.55335\"
Expand-Archive -LiteralPath $Archive -DestinationPath $WorkFolder -Force
Get-ChildItem -Recurse $WorkFolder | Unblock-File


