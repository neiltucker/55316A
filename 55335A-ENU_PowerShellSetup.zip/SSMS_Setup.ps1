# Setup SQL Server Management Studio

# URL for SSMS installer
$ssmsUrl = "https://aka.ms/ssmsfullsetup"
$installerPath = "$env:TEMP\SSMS-Setup-ENU.exe"

# Download and setup SSMS
Invoke-WebRequest -Uri $ssmsUrl -OutFile $installerPath
Start-Process -FilePath $installerPath -ArgumentList "/install /quiet /norestart" -Wait

# Clean up the installer
Remove-Item -Path $installerPath -Force
