-- Importing with BCP and BULK INSERT.

-- 1. Configure environment to run xp_cmdshell for command-line tools (e.g. bcp)
EXECUTE sp_configure 'show advanced options', 1
GO  
RECONFIGURE  
GO  
EXECUTE sp_configure 'xp_cmdshell', 1
GO  
RECONFIGURE  
GO  

-- 2. Create the CustomersImport1 and CustomersImport2 in the AdventureWorks2019 database
USE [AdventureWorks2019]
GO
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'CustomersImport1') DROP TABLE CustomersImport1
GO
CREATE TABLE [dbo].[CustomersImport1](
	[CustomerID] [nvarchar](50) NOT NULL,
	[LastName] [nvarchar](50) NOT NULL,
	[FirstName] [nvarchar](50) NOT NULL,
	[Phone] [nvarchar](50) NULL,
	[Street] [nvarchar](50) NULL,
	[City] [nvarchar](50) NULL,
	[State] [nvarchar](50) NULL,
	[ZipCode] [nvarchar](50) NULL
)
GO

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'CustomersImport2') DROP TABLE CustomersImport2
GO
CREATE TABLE [dbo].[CustomersImport2](
	[CustomerID] [nvarchar](50) NOT NULL,
	[LastName] [nvarchar](50) NOT NULL,
	[FirstName] [nvarchar](50) NOT NULL,
	[Phone] [nvarchar](50) NULL,
	[Street] [nvarchar](50) NULL,
	[city] [nvarchar](50) NULL,
	[State] [nvarchar](50) NULL,
	[ZipCode] [nvarchar](50) NULL
)
GO

-- 3. Import the data into CustomersImport1 using BULK INSERT
BULK INSERT dbo.CustomersImport1
FROM 'C:\Classfiles\customers.csv'
WITH (
DATAFILETYPE = 'char',
FIRSTROW = 2,
FIELDTERMINATOR = ','
)
GO

-- 4. Import data into CustomersImport2 uisng bcp
Execute  master.dbo.xp_cmdshell ' bcp customersimport2 in "C:\Classfiles\customers.csv" -S mia-sql.contoso.com -d adventureworks2019 -T -c -t "," -F 2 '

-- 5. Query both tables to verify that both import operations worked
USE AdventureWorks2019
GO
SELECT * FROM CustomersImport1

SELECT * FROM CustomersImport2

/* 
SELECT * FROM OPENROWSET ( BULK 'C:\Classfiles\Customers.csv',SINGLE_CLOB ) AS Customers
*/