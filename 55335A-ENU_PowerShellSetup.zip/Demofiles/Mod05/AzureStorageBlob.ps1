﻿### Create Azure Storage Blob

### Startup Screen
Clear-Host
Write-Output "Create Azure Storage Blob to be used as SQL Server database backup location"

### 1. Configure Objects & Variables
Set-StrictMode -Version 2.0
# Register-AzResourceProvider -ProviderNameSpace Microsoft.DataProtection
$Labfiles = "C:\Classfiles"
Set-Location $Labfiles
$CredentialsFile = "C:\Classfiles\credentials.txt"	       	# Credentials File
$AzureBackupFile = "C:\Classfiles\AzureBackup.sql"		    # Azure Backup File 
$Location = "EASTUS"
$NamePrefix = "55316" + "in" + (Get-Date -Format "mmss")    # Replace "init" with your initials
$ResourceGroupName = $NamePrefix + "rg"
$StorageAccountName = $NamePrefix.tolower() + "sa"     	    # Must be lower case
$SAShare = "55316share"
$PolicyName = "55316Policy"
If (Get-Module -ListAvailable -Name Az) {Write-Output "Az module already installed" ; Import-Module Az} Else {Install-Module -Name Az -AllowClobber -Force ; Import-Module -Name Az}

### 2. Login to Azure
Connect-AzAccount
$SubscriptionName = (Get-AzSubscription).Name
$Subscription = Get-AzSubscription -SubscriptionName $SubscriptionName | Select-AzSubscription

### 3. Create Resource Group, Storage Account & Setup Resources
$ResourceGroup = New-AzResourceGroup -Name $ResourceGroupName  -Location $Location
$StorageAccount = New-AzStorageAccount -ResourceGroupName $ResourceGroupName -Name $StorageAccountName -Location $location -Type Standard_RAGRS
$StorageAccountKey = (Get-AzStorageAccountKey -ResourceGroupName $ResourceGroupName -Name $StorageAccountName)[0].Value
$StorageAccountContext = New-AzStorageContext -StorageAccountName $StorageAccountName -StorageAccountKey $StorageAccountKey
$BlobShare = New-AzStorageContainer -Name $SAShare -Context $StorageAccountContext -Permission Container -Verbose
$CBC = $BlobShare.CloudBlobContainer
$Policy = New-AzStorageContainerStoredAccessPolicy -Container $SAShare -Policy $PolicyName -Context $storageAccountContext -ExpiryTime $(Get-Date).ToUniversalTime().AddYears(10) -Permission "rwld"
$SAS = New-AzStorageContainerSASToken -Policy $PolicyName -Context $StorageAccountContext -Container $SAShare
Write-Output "Cloud Blob Container URL = '$($CBC.Uri.AbsoluteUri)'"
Write-Output "Shared Access Signature = '$($SAS.Substring(1))'"

### 4. Generate credential and sql backup files
Write-Output "Cloud Blob Container URL = '$($CBC.Uri.AbsoluteUri)'" > $CredentialsFile
Write-Output "Shared Access Signature = '$($SAS.Substring(1))'" >> $CredentialsFile
$line1 = "CREATE CREDENTIAL [{0}] WITH IDENTITY='Shared Access Signature', SECRET='{1}'" -f $cbc.Uri,$sas.Substring(1)
$line2 = "SELECT * FROM sys.credentials"
$line3 = "BACKUP DATABASE aw TO URL = '" + $CBC.Uri.AbsoluteUri + "/aw_azurestorageblob.bak'"
$line1 > $AzureBackupFile
Write-Output "" >> $AzureBackupFile
$line2 >> $AzureBackupFile
Write-Output "" >> $AzureBackupFile
$line3 >> $AzureBackupFile
Write-Output "" >> $AzureBackupFile

### 5. After using the Azure Backup SQL script to create a backup, verify that it was successful
Get-AzStorageBlob -Container $SAShare -Context $StorageAccountContext

### 6. Delete Resources and Log out of Azure
# Remove-AzResourceGroup -Name $ResourceGroupName -Verbose -Force
# Disconnect-AzAccount

