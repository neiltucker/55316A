-- One solution to AWTest14 database being full.  
-- Enable autogrowth for the data and log files

USE master
GO
ALTER DATABASE AWTEST14 MODIFY FILE ( NAME = 'AWTest14', FILEGROWTH = 10%)
GO
ALTER DATABASE AWTEST14 MODIFY FILE ( NAME = 'AWTest14_log', FILEGROWTH = 10%)
GO
