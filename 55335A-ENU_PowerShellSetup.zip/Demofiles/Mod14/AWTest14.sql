-- Create a database and disable autogrowth for the data and log files.
-- Keep filling a table until the database runs out of space.

-- 1. Create AWTest14 database
USE master
GO
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'AWTest14') DROP DATABASE AWTest14
GO
CREATE DATABASE AWTEST14
ON
( NAME = 'AWTEST14', 
  FILENAME = 'C:\Data\AWTEST14.mdf', 
  SIZE = 20MB, 
  FILEGROWTH = 0)
LOG ON 
( NAME = 'AWTEST14_log', 
  FILENAME = 'C:\Log\AWTEST14_log.ldf', 
  SIZE = 10MB, 
  FILEGROWTH = 0)
GO
ALTER DATABASE AWTEST14 SET RECOVERY FULL
GO

-- 2. Create and populate testable1
USE AWTEST14 
GO
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'testtable1') DROP TABLE testtable1
GO
CREATE TABLE testtable1 (
ID INT IDENTITY PRIMARY KEY,
RandomData1 NVARCHAR(50)
)
GO

WHILE (1 = 1)
BEGIN 
   INSERT INTO testtable1 VALUES ('Random: ' + CAST(NEWID() as nvarchar(40)))
END
GO
