### Install Azure Modules

# Set PSGallery as a trusted repository
Set-PSRepository -Name PSGallery -InstallationPolicy Trusted

# Install NuGet PackageProvider
if (-not (Get-PackageProvider -Name NuGet -ErrorAction SilentlyContinue)) {
    Write-Output "Installing NuGet PackageProvider..."
    Install-PackageProvider -Name "NuGet" -Force
} else {
    Write-Output "NuGet PackageProvider already installed."
}

# Install PowerShellGet module
if (-not (Get-Module -ListAvailable -Name PowerShellGet -ErrorAction SilentlyContinue)) {
    Write-Output "Installing PowerShellGet module..."
    Install-Module -Name PowerShellGet -Force -AllowClobber
} else {
    Write-Output "PowerShellGet module already installed."
}

# Install AzureRM module
if (-not (Get-Module -ListAvailable -Name AzureRM -ErrorAction SilentlyContinue)) {
    Write-Output "Installing AzureRM module..."
    Install-Module -Name AzureRM -Force -AllowClobber
    Import-Module -Name AzureRM
} else {
    Write-Output "AzureRM module already installed."
    Import-Module -Name AzureRM
}

# Install SQLServer module
if (-not (Get-Module -ListAvailable -Name SQLServer -ErrorAction SilentlyContinue)) {
    Write-Output "Installing SQLServer module..."
    Install-Module -Name SQLServer -Force -AllowClobber
    Import-Module -Name SQLServer
} else {
    Write-Output "SQLServer module already installed."
    Import-Module -Name SQLServer
}

# Install AzureAD module
if (-not (Get-Module -ListAvailable -Name AzureAD -ErrorAction SilentlyContinue)) {
    Write-Output "Installing AzureAD module..."
    Install-Module -Name AzureAD -Force -AllowClobber
    Import-Module -Name AzureAD
} else {
    Write-Output "AzureAD module already installed."
    Import-Module -Name AzureAD
}

